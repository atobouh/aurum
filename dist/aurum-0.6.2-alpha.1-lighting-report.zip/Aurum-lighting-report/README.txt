Aurum 0.6.2-alpha.1 lighting report

1. Extract the entire ZIP (Windows: right-click, Extract All).
2. Open Aurum-lighting-report/index.html in Chrome, Edge or Firefox.
3. Keep index.html, evidence.json and the media folder together.

All 39 original PNG screenshots and 3 WebM clips are included.
They load offline, without GitHub, a local server or installation.
The alpha JAR download is a separate online link inside the report.

This is an experimental lighting milestone. Cave acceptance, dynamic
voxel source transport and target Intel UHD measurements remain open.
