Extract the entire ZIP. Open Aurum-Excalibur-research/index.html in Chrome, Edge or Firefox. Keep the media folder beside it. All 15 images are included.

Research only. No new mod JAR. YouTube trailer playback remains pending; the report says which reference material was actually reviewed.

Reference gallery: Excalibur / Maffhew, attributed Modrinth images. The resource pack itself is not included.
