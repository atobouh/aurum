Extract All, then open Aurum-surface-depth-research/index.html in a browser. Keep media beside index.html. All six figures and the interactive schematic work offline.

The three supplied stills in chat are analysed in the text. Creator gallery images are labelled as supporting references, not those video frames. Charts are measured statistics. Earlier Minecraft baseline captures are unchanged. No new renderer or mod JAR. No raw copyrighted material textures are included.
